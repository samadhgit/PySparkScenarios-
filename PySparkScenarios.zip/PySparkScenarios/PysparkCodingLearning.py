# Databricks notebook source
# MAGIC %md
# MAGIC # PySpark Coding HandsOn

# COMMAND ----------

# MAGIC %md
# MAGIC ### Importing required Libraries
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import *
from pyspark.sql import SparkSession

# COMMAND ----------

# MAGIC %md
# MAGIC ###DATA READING CSV FILE
# MAGIC

# COMMAND ----------

df = spark.read.format("csv")\
    .option("inferSchema", True)\
    .option("header", True)\
    .load("/Volumes/testg/default/pysparkcoding/BigMart Sales.csv")
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### How to check the URLs where our file reseides

# COMMAND ----------

dbutils.fs.ls("/Volumes/testg/default/pysparkcoding/")

# COMMAND ----------

# MAGIC %md
# MAGIC ###DATA READING JSON FILE

# COMMAND ----------

df_json = spark.read.format("json")\
    .option("inferSchema", True)\
    .option("header", True)\
    .load("/Volumes/testg/default/pysparkcoding/drivers.json/")

df_json.display()

# COMMAND ----------

df_json = spark.read.format("json")\
    .option("inferSchema", True)\
    .option('multiline', False)\
    .option("header", True)\
    .load("/Volumes/testg/default/pysparkcoding/drivers.json/")

df_json.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### SCHEMA - DDL and StructType()

# COMMAND ----------

display(df)

# COMMAND ----------

# Schema Definition
df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### DDL Schema

# COMMAND ----------

# We are going to change one of the data type for the Schema of the table
# Want to convert item_weight from double to string

my_ddl_schema = '''
Item_Identifier string,
Item_Weight string,
Item_Fat_Content string,
Item_Visibility double,
Item_Type string,
Item_MRP double,
Outlet_Identifier string,
Outlet_Establishment_Year integer,
Outlet_Size string,
Outlet_Location_Type string,
Outlet_Type string,
Item_Outlet_Sales double
'''


# COMMAND ----------

df = spark.read.format("csv")\
    .schema(my_ddl_schema)\
    .option("header", True)\
    .load("/Volumes/testg/default/pysparkcoding/BigMart Sales.csv")
df.printSchema()
df.display()


# COMMAND ----------

# MAGIC %md
# MAGIC ### StructType Schema

# COMMAND ----------

my_structschema= StructType([
    StructField("Item_Identifier", StringType(), True),
    StructField("Item_Weight", DoubleType(), True),
    StructField("Item_Fat_Content", StringType(), True),
    StructField("Item_Visibility", DoubleType(), True),
    StructField("Item_Type", StringType(), True),
    StructField("Item_MRP", DoubleType(), True),
    StructField("Outlet_Identifier", StringType(), True),
    StructField("Outlet_Establishment_Year", IntegerType(), True),
    StructField("Outlet_Size", StringType(), True),
    StructField("Outlet_Location_Type", StringType(), True),
    StructField("Outlet_Type", StringType(), True),
    StructField("Item_Outlet_Sales", DoubleType(), True)
])                                                                                                                                                                                                                                                         

# COMMAND ----------

df = spark.read.format("csv")\
          .schema(my_structschema)\
          .option("header", True)\
          .load("/Volumes/testg/default/pysparkcoding/BigMart Sales.csv")
df.printSchema()
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##BASIC `DATA` TRANSFORMATIONS
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### SELECT

# COMMAND ----------

SelectedColumn = df.select("Item_Identifier","Item_Weight","Item_Fat_Content")
display(SelectedColumn)

# COMMAND ----------

selectwithcolname = df.select(col("Item_Identifier"),col("Item_Weight"),col("Item_Fat_Content")).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### ALIAS

# COMMAND ----------

df.select(col('Item_Identifier').alias('Item_Id')).display()
          

# COMMAND ----------

# MAGIC %md
# MAGIC ### FILTER/WHERE
# MAGIC - 1) Filter the data with fat content = Regular
# MAGIC - 2) Slice the data with item type = Soft Drinks and weight < 10
# MAGIC - 3) Fetch the data with Tier in (Tier 1 or Tier 2) and Outlet Size is Null

# COMMAND ----------

# Filter the data with fat content = Regular
df.filter(col("Item_Fat_Content")=="Regular").display()

# COMMAND ----------

# Slice the data with item type = Soft Drinks and weight < 10
df.filter((col("Item_Type")=="Soft Drinks") & (col("Item_Weight")<10)).display()

# COMMAND ----------

# DBTITLE 1,Untitled
# Fetch the data with Tier in (Tier 1 or Tier 2) and Outlet Size is Null
df.filter((col('Outlet_Size').isNull()) & (col('Outlet_Location_Type').isin('Tier 1','Tier 2'))).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### withColumnRenamed

# COMMAND ----------

df.withColumnRenamed("Item_Weight", "Item_Wgt").display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###withColumn

# COMMAND ----------

df = df.withColumn("flag", lit("New"))

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.withColumn("Multiply", col("Item_weight") * col("Item_MRP"))
df.display()

# COMMAND ----------

# DBTITLE 1,Cell 36
df = df.withColumn('Item_Fat_Content', regexp_replace('Item_Fat_Content', "Regular", "Reg"))\
       .withColumn('Item_Fat_Content', regexp_replace('Item_Fat_Content', "Low Fat", "LF"))
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Type Casting

# COMMAND ----------

# Used for cast our column, moreover used for join, basically changing the datatype
df = df.withColumn("Item_Weight", col("Item_Weight").cast(DoubleType()))
df = df.withColumn("Item_MRP", col("Item_MRP").cast(DoubleType()))
display(df)
df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sort/OrderBy

# COMMAND ----------

df.sort(col('Item_Weight').desc()).display()

# COMMAND ----------

df.sort(col('Item_Visibility').asc()).display()

# COMMAND ----------

# Sorting based on multiple columns
df.sort(['Item_Weight','Item_Visibility'],ascending = [0, 0]).display()

# COMMAND ----------

# Sorting of ascending in one column and descending in another column
df.sort(['Item_Weight','Item_Visibility'],ascending = [0, 1]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Limit

# COMMAND ----------

df.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### DROP

# COMMAND ----------

# Dropping 1 column
df.drop('Item_Visibility').display()

# COMMAND ----------

# Dropping 2 columns
df.drop('Item_Visibility','Item_Type').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##INTERMEDIATE DATA TRANSFORMATIONS
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### DROP Duplicates

# COMMAND ----------

# It is called as Deduplication, which remove duplicates for all the columns
df.dropDuplicates().display()

# COMMAND ----------

# Removing Duplicates for specific column
df.drop_duplicates(subset=['Item_Type']).display()

# COMMAND ----------

# another method of duplicate on single column
df.distinct().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###UNION and UNION BY NAME

# COMMAND ----------

# First of all undersand the Union function, it is nothing but joining two tables, thats it
# Preparing DataFrames

Table1 = [('1','kad'),
          ('2','sid')]
schema1 = 'id STRING, name STRING' 

df1 = spark.createDataFrame(Table1,schema1)

Table2 = [('3','rahul'),
          ('4','jas')]
schema2 = 'id STRING, name STRING'
df2 = spark.createDataFrame(Table2,schema2)


# COMMAND ----------

df1.display()

# COMMAND ----------

df2.display()

# COMMAND ----------

# Union of two tables
df1.union(df2).display()

# COMMAND ----------

# Union by name
# when Union by name help, if the data frame one has name and id column, and dataframe two has id and name column, then it will join the dataframes
df1.unionByName(df2).display()


# COMMAND ----------

# MAGIC %md
# MAGIC ### STRING FUNCTIONS
# MAGIC - INITCAP()
# MAGIC - UPPER()
# MAGIC - LOWER()

# COMMAND ----------

df.select(initcap('Item_Type')).limit(10).display()

# COMMAND ----------

df.select(lower('Item_Type')).limit(10).display()


# COMMAND ----------

df.select(upper('Item_Type')).limit(10).display()

# COMMAND ----------

df.select(upper('Item_Type').alias('Upper_Item_Type')).limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### DATE FUNCTIONS
# MAGIC - CURRENT_DATE()
# MAGIC - DATE_ADD()
# MAGIC - DATE_SUB()

# COMMAND ----------

df = df.withColumn('curr_date', current_date())
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### DATE_ADD()

# COMMAND ----------

df = df.withColumn("week_after", date_add('curr_date', 7))

df.display()

# COMMAND ----------

df.withColumn("Week_Before", date_sub('curr_date', 7)).limit(10).display()

# COMMAND ----------

df = df.withColumn('week_before',date_add('curr_date',-7)) 

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###DateDIFF

# COMMAND ----------

df = df.withColumn('datediff',datediff('week_after','curr_date'))

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Date_Format()

# COMMAND ----------

df = df.withColumn("week_before",date_format('week_before','dd-MM-yyyy'))
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### HANDLING NULLS

# COMMAND ----------

# We have two categories - dropping nulls and filling nulls
# DROPPING NULLS - with option any(drop that particular record) and all(drop only if all columns are null)
df.dropna('all').display()

# COMMAND ----------

df.dropna('any').display()
# FILLING NULLS - with option any(fill that particular record) and all(fill only if all columns are null)

# COMMAND ----------

# subset function to drop nulls which is good for multiple columns
df.dropna(subset=['Outlet_Size']).display()

# COMMAND ----------

# Fill the null values
# Replacing the null value with custom value for specific column or all column
df.fillna('NotAvailable').display()

# COMMAND ----------

df.fillna('Not Available', subset=["Outlet_Size"]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### SPLIT and Indexing

# COMMAND ----------

# Working with OutletType column and break into supermarket and type, similarly process for all rows
df.withColumn('Outlet_Type', split(col('Outlet_Type'),' ')).display()
# Now the column is converted to the list, now we can make use of indexing

# COMMAND ----------

# Display the value available in Indexing using Outlet Type
# Indexing
df.withColumn('Outlet_Type', split(col('Outlet_Type'),' ')[1]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### EXPLODE

# COMMAND ----------

# Explode is used to split the list into multiple rows, let say we have type1, supermarket, we just create new rows separately based on Tier
# We need to create dataframe for the list, then we can explode it
df_exp = df.withColumn('Outlet_Type', split(col('Outlet_Type'),' '))
df_exp.display()

# COMMAND ----------

# Explode from the variable df_exp
df_exp.withColumn('Outlet_Type', explode(col('Outlet_Type'))).display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### ARRAY_CONTAINS

# COMMAND ----------

# This function strongly aligned with split function, becoz we work with Array column with the help of this function
# 1D Array - We want to know if Type1 / SuperMarket is available at the column
df_exp.withColumn('Type1_flag', array_contains('Outlet_Type','Type1')).display()
# The new column will result in True or false for the column name "Type1_flag"

# COMMAND ----------

# MAGIC %md
# MAGIC ### GROUP_BY

# COMMAND ----------

# We are going to apply group by with the Column Item Type and sum of Item MRP aggregation
# Perfrom aggregation based on each Item type
# Scenario-1: [Total Sum of MRP for each Type]
df.groupBy('Item_Type').agg(sum('Item_MRP').alias('Total_Sum')).display()

# COMMAND ----------

# Scenario-2: [Average value of each Type]
df.groupBy('Item_Type').agg(avg('Item_MRP').alias('Total_Average')).display()

# COMMAND ----------

#Scenario-3: I want to apply group by on Item Type, Outlet price followed by aggregation of total mrp
df.groupBy('Item_Type', 'Outlet_Size').agg(sum('Item_MRP').alias('Total_MRP')).display()

# COMMAND ----------

# Scenario-4: Based on the above scenario, we just include average mrp as well thats it, just leveling up
df.groupBy('Item_Type', 'Outlet_Size').agg(sum('Item_MRP').alias('Total_MRP'),avg('Item_MRP').alias('Average_MRP')).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##ADVANCED DATA TRANSFORMATIONS
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### COLLECT_LIST

# COMMAND ----------

# Basically what it does, we have a column of user which has user1, user1, user2, user2, user3 like this, then we have another column book which has book1 book2, book2, book4, book1
# So this collect_list function just group the first column and associated values of second column will be grouped and updated as list
# user1 ["book1", "book2"]
# user2 ["book2", "book4"]
# user3 ["book1"]

data = [('user1','book1'),
        ('user1','book2'),
        ('user2','book2'),
        ('user2','book4'),
        ('user3','book1')]
schema = 'user string, book string'
df_book = spark.createDataFrame(data, schema)
df_book.display()

# COMMAND ----------

df_book.groupBy('user').agg(collect_list('book').alias('Books')).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### PIVOT

# COMMAND ----------

# Pivot function helps us to create two columns with aggregation, let say Item type has it values in each row, similarly outlet size is kept at top row on each column, the itemMRP value is assigned to each itemtype based on the outlsize category
df.groupBy('Item_Type').pivot('Outlet_Size').agg(avg("Item_MRP")).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### WHEN-OTHERWISE

# COMMAND ----------

# DBTITLE 1,WHEN-OTHERWISE scenario1
# It is like CASE WHEN Statement in SQL, that is how WHEN-OTHERWISE will work
# With our table data, based on item_type we will check if it is veg or non-veg
# Scenario1:
df = df.withColumn('Veg_Flag', when(col('Item_Type')=='Meat','Non_Veg').otherwise('Veg'))
df.display()

# COMMAND ----------

df.display()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# Scenario2:
# If my item_type is veg and item_MRP is more than 100, then create flag as veg expnesive and if not veg inexpensive, otherwise non-veg
df.withColumn('Veg_exp_flag',when(((col('Veg_Flag')=='Veg') & (col('Item_MRP')<100)), 'Veg_Inexpensive')\
                            .when((col('Veg_Flag')=='Veg') & (col('Item_MRP')>100), 'Veg_Expensive')\
                            .otherwise('Non_Veg')).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### JOINS
# MAGIC   - INNER JOIN
# MAGIC   - LEFT JOIN
# MAGIC   - RIGHT JOIN
# MAGIC   - FULL JOIN
# MAGIC   - ANTI JOIN

# COMMAND ----------

# Inner Join
# CompDataFrame1
data = [
    (1, "gaur", "d01"),
    (2, "kit", "d02"),
    (3, "sam", "d03"),
    (4, "tim", "d03"),
    (5, "aman", "d05")
]

schema = StructType([
    StructField("emp_id", IntegerType(), True),
    StructField("emp_name", StringType(), True),
    StructField("dept_id", StringType(), True)
])    

comp_df1 = spark.createDataFrame(data, schema)
comp_df1.display()

# COMMAND ----------

# Inner Join
# CompDataFrame2

data = [
    ("d01", "HR"),
    ("d02", "Marketing"),
    ("d03", "Accounts"),
    ("d04", "IT"),
    ("d05", "Finance")
]

schema = StructType(
    [StructField("dept_id", StringType(), True),
     StructField("department", StringType(), True)
])

comp_df2 = spark.createDataFrame(data, schema)
comp_df2.display()

# COMMAND ----------

# Performing Inner Join
comp_df1.join(comp_df2, comp_df1['dept_id'] == comp_df2['dept_id'],'inner').display()

# COMMAND ----------

# Left Join

data_j1 = [
    (1, "gaur", "d01"),
    (2, "kit", "d02"),
    (3, "sam", "d03"),
    (4, "tim", "d03"),
    (5, "aman", "d05"),
    (6, "nad", "d06")
]

schema_j1 = 'emp_id INTEGER, emp_name STRING, dept_id STRING'

data_j2 = [
    ("d01", "HR"),
    ("d02", "Marketing"),
    ("d03", "Accounts"),
    ("d04", "IT"),
    ("d05", "Finance")
]

schema_j2 = 'dept_ID STRING, department STRING'

df1 = spark.createDataFrame(data_j1, schema_j1)
df2 = spark.createDataFrame(data_j2, schema_j2)

df1.join(df2, df1['dept_id'] == df2['dept_ID'],'left').display()

# COMMAND ----------

# Right Join

data_j1 = [
    (1, "gaur", "d01"),
    (2, "kit", "d02"),
    (3, "sam", "d03"),
    (4, "tim", "d03"),
    (5, "aman", "d05"),
    (6, "nad", "d06")
]

schema_j1 = 'emp_id INTEGER, emp_name STRING, dept_id STRING'

data_j2 = [
    ("d01", "HR"),
    ("d02", "Marketing"),
    ("d03", "Accounts"),
    ("d04", "IT"),
    ("d05", "Finance")
]

schema_j2 = 'dept_id STRING, department STRING'

df1 = spark.createDataFrame(data_j1, schema_j1)
df2 = spark.createDataFrame(data_j2, schema_j2)

df1.join(df2, df1['dept_id'] == df2['dept_id'],'right').display()


# COMMAND ----------

# ANTI JOIN
data_j1 = [
    (1, "gaur", "d01"),
    (2, "kit", "d02"),
    (3, "sam", "d03"),
    (4, "tim", "d03"),
    (5, "aman", "d05"),
    (6, "nad", "d06")
]

schema_j1 = 'emp_id INTEGER, emp_name STRING, dept_id STRING'

data_j2 = [
    ("d01", "HR"),
    ("d02", "Marketing"),
    ("d03", "Accounts"),
    ("d04", "IT"),
    ("d05", "Finance")
]

schema_j2 = 'dept_id STRING, department STRING'

df1 = spark.createDataFrame(data_j1, schema_j1)
df2 = spark.createDataFrame(data_j2, schema_j2)

df1.join(df2, df1['dept_id'] == df2['dept_id'],'anti').display()


# COMMAND ----------

# MAGIC %md
# MAGIC ## WINDOW FUNCTIONS

# COMMAND ----------

# MAGIC %md
# MAGIC ### ROW_NUMBER()
# MAGIC ### RANK()
# MAGIC ### DENSE_RANK()
# MAGIC ### LEAD()
# MAGIC ### LAG()

# COMMAND ----------

# ROW NUMBER()
display(df)

# COMMAND ----------

df.withColumn('Row_ID',row_number().over(Window.orderBy('Item_Identifier'))).display()

# COMMAND ----------

# RANK()
df.withColumn("Rank_col", rank().over(Window.orderBy('Item_Identifier'))).display()

# COMMAND ----------

df.withColumn("DenseRank_col", dense_rank().over(Window.orderBy('Item_Identifier'))).display()

# COMMAND ----------

# RANK() with descending order
df.withColumn("Rank_col", rank().over(Window.orderBy(col('Item_Identifier').desc()))).display()

# COMMAND ----------

# RANK() and Dense_Rank with descending order
df.withColumn("Rank_col", rank().over(Window.orderBy(col('Item_Identifier').desc())))\
  .withColumn("DenseRank_col", dense_rank().over(Window.orderBy(col('Item_Identifier').desc())))\
  .display(df)

# COMMAND ----------

# Cumulative Sum
df.limit(10).display()

# COMMAND ----------

# Total Sum for each ItemType applied
df.withColumn('Running_Sum',sum('Item_MRP').over(Window.orderBy('Item_Type'))).display()

# COMMAND ----------

# Running_Total / Running sum / Cumulative sum
df.withColumn('Running_Sum',sum('Item_MRP').over(Window.orderBy('Item_Type').rowsBetween(Window.unboundedPreceding, Window.currentRow))).display()

# COMMAND ----------

# Total sum of all the record
df.withColumn('Total_Sum',sum('Item_MRP').over(Window.orderBy('Item_Type').rowsBetween(Window.unboundedFollowing, Window.currentRow))).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## UDF - UserDefinedFunctions

# COMMAND ----------

# Why do we use UDF?
# - If we want to perform a transformation, which cannot be acheived with the pre-defined functions in spark, we can use any of the python functions which are not available or not supported by spark, we can use UDF
# Basically spark is not suggested to use user defined function as due to serialization and deserialization overhead, it will take more time to process the data.
# But if we have to use UDF, we can use it as below:
#- In the below example, we are using the python function 'len' to get the length of the string, which is not supported by spark, so we are using UDF to get the length of the string.
#- We can also use the python function 'len' directly in the withColumn function, but it will not be supported by spark, so we are using UDF to get the length of the string.
# UDF
#from pyspark.sql.functions import udf
#len_udf = udf(lambda x: len(x))
# Using UDF
#df.withColumn('Item_Type_Length',len_udf('Item_Type')).display()
# Window Function with UDF
#from pyspark.sql.functions import udf
#len_udf = udf(lambda x: len(x)) # UDF
#df.withColumn('Item_Type_Length',len_udf('Item_Type'))\
#  .withColumn('Running_Sum',sum('Item_Type_Length').over(Window.orderBy('Item_Type').rowsBetween(Window.unboundedPreceding, Window.#currentRow)))\
#  .display()    

# COMMAND ----------

# UDF own functions
#step-1

def my_fun(x):
    return x*x

# COMMAND ----------

#step-2
my_udf = udf(my_fun)

# COMMAND ----------

#step-3
df.withColumn('New_column', my_udf('Item_MRP')).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## DATA WRITING

# COMMAND ----------

# MAGIC %md
# MAGIC ### CSV File format

# COMMAND ----------

df.write.format('csv')\
  .save('/Volumes/testg/default/pysparkcoding/data.csv/')

# COMMAND ----------

# MAGIC %md
# MAGIC ### DATA WRITING MODES
# MAGIC - APPEND
# MAGIC   - This mode is handy if we dont want to lose the data, we have dataframe and we have a same file already there in datalake, when we ran this append mode, it just update the file on top of that existing file.
# MAGIC - OVERWRITE
# MAGIC   - This is sensitive, we have file data.csv and just overwrite it from the latest dataframe, delete the existing file and replaced with new file
# MAGIC - ERROR
# MAGIC   - It run the command, if the folder is there, just tell that we have a file and it displays the error
# MAGIC - IGNORE
# MAGIC   - It will check, if the file is there just ran the command, and no changes will happen on data lake side

# COMMAND ----------

# APPEND
df.write.format('csv')\
  .mode('append')\
  .option('path','/Volumes/testg/default/pysparkcoding/data.csv/')\
  .save()

# COMMAND ----------

# OVERWRITE
df.write.format('csv')\
  .mode('overwrite')\
  .option('path','/Volumes/testg/default/pysparkcoding/data.csv/')\
  .save()

# COMMAND ----------

# ERROR
df.write.format('csv')\
  .mode('error')\
  .option('path','/Volumes/testg/default/pysparkcoding/data.csv/')\
  .save()

# COMMAND ----------

# IGNORE
df.write.format('csv')\
  .mode('ignore')\
  .option('path','/Volumes/testg/default/pysparkcoding/data.csv/')\
  .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ## PARQUET FILE FORMAT

# COMMAND ----------

df.write.format('parquet')\
  .mode('overwrite')\
  .option('path','/Volumes/testg/default/pysparkcoding/data.parquet/')\
  .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ## DELTA LIVE FORMAT

# COMMAND ----------

df.write.format('delta')\
  .mode('overwrite')\
  .option('path','/Volumes/testg/default/pysparkcoding/data.delta/')\
  .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ### TABLE

# COMMAND ----------

# Managed Table
df.write.format('delta')\
  .mode('overwrite')\
  .saveAsTable('My_Table')

# COMMAND ----------

# MAGIC %md
# MAGIC ### MANAGED vs EXTERNAL TABLES
# MAGIC - Managed:
# MAGIC   - Managed Table we can use it inside the databricks and if we create any new file and on with that we create table on that file, if we drop the table, it will delete both Table and as well as file
# MAGIC - External:
# MAGIC   - External Table can be used in external datalake, where file is available at S3 Bucket or data lake storage, where the table is avaialble inside the catalog, if we perform drop table option it will delete only the table, there is no impact for the external file

# COMMAND ----------

# MAGIC %md
# MAGIC ## Spark SQL

# COMMAND ----------

df.display()

# COMMAND ----------

# Create Temp View to perform spark SQL
df.createTempView('my_view')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM my_view WHERE Item_Fat_Content='LF'

# COMMAND ----------

#write the data in sql table
df_sql = spark.sql("select * from my_view WHERE Item_Fat_Content = 'LF'")
df_sql.write.format('delta')\
  .mode('overwrite')\
  .saveAsTable('My_Table')


# COMMAND ----------

df_sql.display()

# COMMAND ----------

