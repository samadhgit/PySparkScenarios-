# Databricks notebook source
# MAGIC %md
# MAGIC **PySpark Real-Time Scenarios For Big Data Engineers [JOB READY 2025]**
# MAGIC - https://www.youtube.com/watch?v=-Gvnm9eS8v8&t=4881s

# COMMAND ----------

# MAGIC %md
# MAGIC ![image_1772790479759.png](./image_1772790479759.png "image_1772790479759.png")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scenario:1
# MAGIC   - Here we can see upsert daily streaming, we need to apply logic update the old data and insert the new data this is called upsert, we use merge command to perform this.
# MAGIC   - For this we are going to use our hosted platform which is Databricks

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparing Setup
# MAGIC - First we create new notebook for executing all our code in workspace, our mail account, one new folder within that we keep our notebook
# MAGIC - second create new catalog and on top of that create new schema
# MAGIC - Third, we just create one table withing the catalog and schema

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 1️⃣ Drop the Delta table (if registered as a table)
# MAGIC DROP TABLE IF EXISTS products_sink;

# COMMAND ----------

# 2️⃣ Delete the Delta folder (important)
dbutils.fs.rm("/Volumes/pyspark_cata/source/db_volume/products_sink/", True)

# COMMAND ----------

# 3️⃣ Verify folder removed
dbutils.fs.ls("/Volumes/pyspark_cata/source/db_volume/")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Querying Source**

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM pyspark_cata.source.products

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import *

# COMMAND ----------

# Create DataFrame with the below method if it is a table, we can apply incremental load efficiently when using the below query
df = spark.sql("select * FROM pyspark_cata.source.products")
# Dedup

df = df.withColumn("dedup", row_number().over(Window.partitionBy('id').orderBy(desc('updatedDate'))))
df = df.filter(col("dedup")==1).drop('dedup')
display(df)

# Actually we already have the table, so we dont want to execute below to read the data, use the above query only
# df = spark.read.format("delta")\.
               # .load("/Volumes/pyspark_cata/source/db_volume/products/")

# COMMAND ----------

# MAGIC %md
# MAGIC ### UPSERTS

# COMMAND ----------

# Create Delta Object
# This Delta object is used to merge our data from the source to sink in databricks managed unity catalog
# First we import the detla table library
# second we create delta object for the destination to store our delta table
# Third we create merge query to merge the data with the condition even if back dated refresh also exists, it only update if it is the latest data
# Basically we can acheive it using 3 methods, 1st - if condition, second dbutils, third **python code**

from delta.tables import DeltaTable
try: # Incremental load
    dlt_obj = DeltaTable.forPath(spark, "/Volumes/pyspark_cata/source/db_volume/products_sink/")

    dlt_obj.alias("trg").merge(
        df.alias("src"),
        "src.id = trg.id")\
        .whenMatchedUpdateAll(condition="src.updatedDate >= trg.updatedDate")\
        .whenNotMatchedInsertAll()\
        .execute()
    print("This is upserting the data now")
except: # Initial load
    df.write.format("delta")\
      .mode("overwrite")\
      .save("/Volumes/pyspark_cata/source/db_volume/products_sink/")

# COMMAND ----------

#Leveling up the above code

from delta.tables import DeltaTable

if len(dbutils.fs.ls("/Volumes/pyspark_cata/source/db_volume/products_sink/")) > 0:
    
    dlt_obj = DeltaTable.forPath(spark, "/Volumes/pyspark_cata/source/db_volume/products_sink/")
    
    dlt_obj.alias("trg").merge(
        df.alias("src"),
        "src.id = trg.id")\
        .whenMatchedUpdateAll(condition="src.updatedDate > trg.updatedDate")\
        .whenNotMatchedInsertAll()\
        .execute()
    print("This is upserting the data now")

else:
    df.write.format("delta")\
      .mode("overwrite")\
      .save("/Volumes/pyspark_cata/source/db_volume/products_sink/")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Now i can query the data stored on sink side
# MAGIC -- We should see only 5 records instead of 10 or 15
# MAGIC -- When we rerunning the delta object table again, it will update the latest data
# MAGIC -- one more important thing, when we have a new updated record of the same id, we need to implement deduplication with the latest record
# MAGIC SELECT * FROM delta.`/Volumes/pyspark_cata/source/db_volume/products_sink/`

# COMMAND ----------

# MAGIC %md
# MAGIC ![image_1772877697297.png](./image_1772877697297.png "image_1772877697297.png")

# COMMAND ----------

# MAGIC %md
# MAGIC **STREAMING QUERY**

# COMMAND ----------

# Define the Schema
my_schema = """
            order_id INT,
            customer_id INT,
            order_date DATE,
            amount DOUBLE
"""

# COMMAND ----------

# Spark Structured Streaming will help to process the above scenario
# Now we have two files orders_initial, orders_incremental

df_batch = spark.read.format("csv")\
          .option("header", True)\
          .schema(my_schema)\
          .load("/Volumes/pyspark_cata/source/db_volume/streamSource")
display(df_batch)


# COMMAND ----------

# Above code is for verification only, use this code
df = spark.readStream.format("csv")\
          .option("header", True)\
          .schema(my_schema)\
          .load("/Volumes/pyspark_cata/source/db_volume/streamSource")

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Streaming Output**

# COMMAND ----------

# checkpointLocation - which is used to have the metadata information once any file copied from source to destination
# Let say today we upload one file from source to sink, next day we upload another two files, pyspark goes to check point location and check and confirm, there is already one file processed, it will process the another two files
# usually for general databricks account we use .trigger(processingTime="10 seconds")
df.writeStream.format("delta")\
  .option("checkpointLocation", "/Volumes/pyspark_cata/source/db_volume/streamSink/checkpoint")\
  .option("mergeSchema", True)\
  .trigger(once=True)\
  .start("/Volumes/pyspark_cata/source/db_volume/streamSink/data")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta.`/Volumes/pyspark_cata/source/db_volume/streamSink/data/`

# COMMAND ----------

# MAGIC %md
# MAGIC **VALIDATING THE SCENARIO**
# MAGIC - Upload the incrementalcsv file to the streamsource folder, run the df read, run the streaming command we will see it updates the latest data only due to check point enablement

# COMMAND ----------

# MAGIC %md
# MAGIC ![image_1772882319845.png](./image_1772882319845.png "image_1772882319845.png")
# MAGIC

# COMMAND ----------

# This scenario dealing with semistructured data which is in JSON format, the json contains nested fields
# We need to nested structure data using flatten format which is in readable table format
# Working with normal JSON is very easy, we are using nested JSON complex dataset
# We have the json file kept at our source location - /Volumes/pyspark_cata/source/db_volume/jsonData/
# Now Read this data
df = spark.read.format("json")\
    .load("/Volumes/pyspark_cata/source/db_volume/jsonData/")

display(df)

# We will get internal corrupted, actually the file is proper and nested content, to fix this we need to include multiline 

# COMMAND ----------

# As this is a multiline JSON file, we need to enable schema and multiline as True
df = spark.read.format("json")\
    .option("inferSchema", True)\
    .option("multiline", True)\
    .load("/Volumes/pyspark_cata/source/db_volume/jsonData/")

display(df)

# COMMAND ----------

df.schema
# If we want to change any type of the column, we can do it, this was defined by spark, we can tweak this based on our use case

# COMMAND ----------

from pyspark.sql.functions import*

# COMMAND ----------

# How to flatten this JSON
# We see we have lot of columns, how to we write big code to flatted the JSON
# How do we do it for complex project or complex json nested columns, we can't define user defined function for each column, in realtime the data is not generic, we can't write a function for each column
# Databricks has a solution for this, it is called Auto Loader, there is a function called explode, it will explode the nested column and flatten it.
# Now we have flatten the data

df_cust = df.select("customer.customer_id", "customer.email", "customer.location.city", "customer.location.country","*").drop("customer")

df_cust_upd = df_cust.withColumn("delivery_updates", explode("delivery_updates"))\
                     .withColumn("items", explode("items"))\
                     .select("*")
display(df_cust_upd)



# COMMAND ----------

# MAGIC %md
# MAGIC ![image_1772901021930.png](./image_1772901021930.png "image_1772901021930.png")

# COMMAND ----------

# MAGIC %md
# MAGIC ## **PYTHON CLASS**

# COMMAND ----------

# MAGIC %md
# MAGIC - In this class, we keep bunch of functions, those functions are used in class, most are repitive requirement which is used of most common datasets, like deduplication, normalization, etc
# MAGIC - Here class is very easy, let me tell you, 
# MAGIC   - **attributes** in class are nothing but **variables**
# MAGIC     - Car is the class name, car model and brand is the attributes which is variables
# MAGIC   - **methods** in class are nothing but **functions**
# MAGIC     - Drive is the method, where we call it which is nothing but functions
# MAGIC   - car1 and car2 are objects will be created
# MAGIC   - Class is a collection of similar functions, it is blueprint for creating objects

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

# Class in Data validation will validate the data before i want to upsert my data, it might have duplicates in my source data frame, it can use to rank my data, it can remove nulls from my column, so it will be a validator, insted of re-writing the code, will use this class for performing validation on any datasets
# def __init__ - used to ask for the variable, self is the keyword used on every function except some special function
# __init__ always ran when we create variable object, that is the reason we added df within self

class DataValidation:
    
    def __init__(self,df):
        self.df = df
    
    def dedup(self,keyCol,cdcCol):
        df = self.df.withColumn("dedup", row_number().over(Window.partitionBy(keyCol).orderBy(desc(cdcCol))))
        df = df.filter(col('dedup')==1).drop('dedup')

        return df

    def removeNulls(self,nullCol):
        df = self.df.filter(col(nullCol).isNotNull())

        return df

# COMMAND ----------

# We can create SUDO datafram
df = spark.createDataFrame([("1", "2020-01-01", 100), ("2", "2020-01-02", 200), ("3", "2020-01-03", 300), ("1", "2020-01-12", 200)], ["order_id", "order_date", "amount"])
display(df)

# COMMAND ----------

cls_obj = DataValidation(df)

# COMMAND ----------

# DBTITLE 1,Deduplication using DataValidation class
df_dedup = cls_obj.dedup('order_id','order_date')

# COMMAND ----------

display(df_dedup)

# COMMAND ----------

# MAGIC %md
# MAGIC ## **This is AI written code** **Which is for any production or business use case**
# MAGIC
# MAGIC class DataFrameTransformer:
# MAGIC     def __init__(self, df):
# MAGIC         self.df = df
# MAGIC
# MAGIC     def deduplicate(self, key_cols, order_col):
# MAGIC         window = Window.partitionBy(*key_cols).orderBy(desc(order_col))
# MAGIC         return self.df.withColumn("row_num", row_number().over(window)).filter(col("row_num") == 1).drop("row_num")
# MAGIC
# MAGIC     def remove_nulls(self, cols):
# MAGIC         for col_name in cols:
# MAGIC             self.df = self.df.filter(col(col_name).isNotNull())
# MAGIC         return self.df
# MAGIC
# MAGIC     def select_columns(self, cols):
# MAGIC         return self.df.select(*cols)
# MAGIC
# MAGIC     def add_column(self, col_name, expr):
# MAGIC         return self.df.withColumn(col_name, expr)
# MAGIC
# MAGIC     def filter_rows(self, condition):
# MAGIC         return self.df.filter(condition)
# MAGIC
# MAGIC     def rename_columns(self, rename_dict):
# MAGIC         df = self.df
# MAGIC         for old, new in rename_dict.items():
# MAGIC             df = df.withColumnRenamed(old, new)
# MAGIC         return df
# MAGIC
# MAGIC     def drop_columns(self, cols):
# MAGIC         return self.df.drop(*cols)

# COMMAND ----------

# MAGIC %md
# MAGIC ![image_1772948035802.png](./image_1772948035802.png "image_1772948035802.png")
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE pyspark_cata.source.customers;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE pyspark_cata.source.customers
# MAGIC (
# MAGIC   id STRING,
# MAGIC   email STRING,
# MAGIC   city STRING,
# MAGIC   country STRING,
# MAGIC   modifiedDate TIMESTAMP
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO pyspark_cata.source.customers
# MAGIC VALUES
# MAGIC ('1', 'john.doe@example.com', 'New York', 'USA', current_timestamp()),
# MAGIC ('2', 'jane.smith@example.com', 'London', 'UK', current_timestamp()),
# MAGIC ('3', 'mike.jones@example.com', 'Paris', 'France', current_timestamp()),
# MAGIC ('4', 'sara.williams@example.com', 'Tokyo', 'Japan', current_timestamp()),
# MAGIC ('5', 'alex.miller@example.com', 'Sydney', 'Australia', current_timestamp());

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM pyspark_cata.source.customers;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE pyspark_cata.source.DimCustomers;

# COMMAND ----------

if spark.catalog.tableExists("pyspark_cata.source.DimCustomers"):
    pass
else:
    spark.sql("""
              CREATE TABLE pyspark_cata.source.DimCustomers
              SELECT *,
                    current_timestamp() as startTime,
                    CAST('3000-01-01' AS TIMESTAMP) as endTime,
                    'Y' as IsActive              
               FROM pyspark_cata.source.customers
              """)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM pyspark_cata.source.DimCustomers;

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Summarise the scenario as of now we done**
# MAGIC - First we created normal table using sql query
# MAGIC - second we used if condition to update the same table on destination, but we included additional 3 columns as we are going to validate SCD Type2 - startTime will be our current time stamp, endtime will be the far future date and the row status is active or not, this is where it will update the changes

# COMMAND ----------

# MAGIC %md
# MAGIC ## **SCD TYPE2**

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from delta.tables import DeltaTable

# COMMAND ----------

# Source
df = spark.sql("""
               SELECT * FROM pyspark_cata.source.customers               
               """)
# Basically we can use class for deduplication, for that we already have the class ready, we need to save that file as python file

df = df.withColumn("dedup", row_number().over(Window.partitionBy("id").orderBy(desc("modifiedDate"))))\
       .drop('dedup')

df = df.filter(col('dedup') == 1)

df.createOrReplaceTempView('srctemp')

df = spark.sql("""
                SELECT *,
                    current_timestamp() as startTime,
                    CAST('3000-01-01' AS TIMESTAMP) as endTime,
                    'Y' as IsActive              
               FROM srctemp
              """)

df.createOrReplaceTempView('src')

#adding merger condition


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM src

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Merge1 - Marking the updated record as expired**

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO pyspark_cata.source.DimCustomers as trg
# MAGIC USING src as src
# MAGIC ON trg.id = src.id
# MAGIC AND trg.isActive = 'Y'
# MAGIC
# MAGIC WHEN MATCHED AND src.email <> trg.email 
# MAGIC OR src.city <> trg.city 
# MAGIC OR src.country <> trg.country 
# MAGIC OR src.modifiedDate <> trg.modifiedDate
# MAGIC
# MAGIC THEN UPDATE SET 
# MAGIC trg.endTime = current_timestamp(), 
# MAGIC trg.isActive = 'N'

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Merge-2 Inserting New + Updated Records**

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO pyspark_cata.source.DimCustomers as trg
# MAGIC USING src as src
# MAGIC ON src.id = trg.id
# MAGIC AND trg.isActive = 'Y'
# MAGIC
# MAGIC WHEN NOT MATCHED THEN INSERT * 

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM pyspark_cata.source.DimCustomers

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO pyspark_cata.source.customers
# MAGIC VALUES
# MAGIC ('1', 'john.doe@example.com', 'Seattle', 'USA', current_timestamp()),
# MAGIC ('6', 'jane.smith@example.com', 'London', 'UK', current_timestamp())
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ![image_1772972613446.png](./image_1772972613446.png "image_1772972613446.png")
# MAGIC

# COMMAND ----------

